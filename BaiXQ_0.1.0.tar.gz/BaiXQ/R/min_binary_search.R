#' 最小二分法函数
#'
#' @param x 一个有序的序列
#' @param target 目标值
#'
#' @return 目标值在序列中的索引，如果目标值不存在，则返回-1
#'
#' @examples
#' x <- c(1, 2, 3, 4, 5)
#' min_binary_search(x, 3)  # 返回 2
#' min_binary_search(x, 6)  # 返回 -1
min_binary_search <- function(x, target) {
  low <- 1
  high <- length(x)
  while (low <= high) {
    mid <- floor((low + high) / 2)
    if (x[mid] == target) {
      return(mid)
    } else if (x[mid] < target) {
      low <- mid + 1
    } else {
      high <- mid - 1
    }
  }
  return(-1)  # target not found
}
