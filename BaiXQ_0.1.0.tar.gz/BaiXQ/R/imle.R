########### 对数级数分布的极大似然估计（改进版）
grad<-function(p,barx=1.5)
{
  return(-p/(1-p)/log(1-p)-barx)
}
hess<-function(p)
{
  h=(-log(1-p)-p)/(1-p)^2/(log(1-p)^2)
  return(h)
}

epsilon=10^(-8)
n_max=10^3
imle<-function(barx)
{
  x_list=rep(0.5,n_max);
  for (k in 2:n_max) {
    x_list[k]=x_list[k-1]-grad(x_list[k-1],barx)/hess(x_list[k-1]);
    if(abs(x_list[k]-x_list[k-1])<epsilon) {return(x_list[k])}
  }
  return(x_list[n_max])
}
