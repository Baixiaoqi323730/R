#' Buffon's Needle Experiments
#'
#' @param n A number which is the number of experiments.
#' @return The results of n Buffon's needle throwing experiments.
#' @examples
#' needle(1000)
#' needle(10000)
needle=function(n)
{
  l=1
  d=2
  count=0
  for (i in 1:n){
    y=runif(1,0,d/2)
    theta=runif(1,0,pi/2)
    x=l/2*cos(theta)
    if (y<=x) {count=count+1}
  }
  P=count/n
  pi_estimated=(2*l)/(P*d)
  return(pi_estimated)
}
